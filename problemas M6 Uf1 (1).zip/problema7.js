var numero=prompt("Dime un numero");
var i=0;
while (i<11) {
	document.write(numero + " * " + i + " = " + numero*i+"<br />");
	i++;
}

for (i=0;i<11;i++){
	document.write(numero + " * " + i + " = " + numero*i+"<br />");
}



