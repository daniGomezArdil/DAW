var dias = prompt("Introduce un numero de dias");
var aux=dias;
var anyos=0;
while (aux>364){
	aux=aux-365;
	anyos++;
}
alert ("son: años y quedan " +aux +" dias");