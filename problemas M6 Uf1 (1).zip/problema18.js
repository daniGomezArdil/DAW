var horaAct=prompt("Dime que hora es formato HH24:MM");

var donde=horaAct.indexOf(':');
var horas= horaAct.substring(0,donde);
var minutos= horaAct.substring(donde+1);

var minutosRestantes=60-minutos;
var horasRestantes=23-horas;



document.write("Quedan: " + horasRestantes + " horas");
document.write("Quedan: " + minutosRestantes + " minutos");







