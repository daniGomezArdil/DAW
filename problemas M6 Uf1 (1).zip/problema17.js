var numero=Math.floor(Math.random()*100)+1;
var x=0;
var texto;
var intentos=0;
while (x!=numero){
		x=prompt("Dime un numero entre 1 y 100") *1;
		intentos++;
		texto=(x<numero)?"Es muy pequeño":"";
		texto=(x>numero)?"Te has pasado":texto;
		document.write(texto + "<br />");
}
document.write("Felicidades. Has acertado el numero " + numero +". Has necesitado " + intentos + " intentos");