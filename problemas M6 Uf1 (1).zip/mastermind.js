var palabra="JUGAR";
var aux;
var i=10;
var fin=false;
var texto_fin="";
var aux1;
var aux2;
var aux3;
var resultado="";
while (fin==false){
	resultado="";
	//Control si cancela el juego
	aux=prompt("Dime una palabra de 5 letras");
	if (aux===null){
		fin=true;
		texto_fin="Has abandonado. Vuelve cuando quieras";
	}
	
	//Tiene un intento menos.
	i--;
	if (i==0) {
		fin=true;
		texto_fin="Game over. Te has quedado sin intentos";
	}
	// Control si acierta palabra
	if (aux==palabra){
		fin=true;
		texto_fin="Felicidades!!!! Has acertado!"
	}
	//Control tirada normal. 
	if (fin==false){
		for (var j=0;j<palabra.length;j++){
			
			aux1=palabra.charAt(j);
			aux2=aux.charAt(j);
			if (aux1==aux2){
				resultado=resultado+"X";
			}
			else {
				aux3=palabra.indexOf(aux2);
				if (aux3==-1){
					resultado=resultado+"-";
				}
				else {
					resultado=resultado+"O";
				}
			}
		}
		var ventana;
		ventana=window.open("","nueva","width=200");
		ventana.document.write(resultado);
		setTimeout(function(){ 
			window.close();
		},1500);
		
		/*
		ventana.document.write(resultado);
		ventana.document.write("<script>");
		ventana.document.write("setTimeout(function(){ window.close();},1500);");
		ventana.document.write("</script>");
		*/
		
	}
	
}

//RESULTADO FINAL
alert(texto_fin);



















