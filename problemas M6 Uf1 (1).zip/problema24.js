var texto=prompt("Dime el texto codificado");
var letra=prompt("Dime la clave para descifrar");

var i;
var aux='';
var caracter;
for (i=0;i<texto.length-1;i++){
	caracter=texto.charAt(i);
	if (caracter==letra){
		aux+=texto.charAt(i+1);
	}
	else{
		//do nothing
	}
}
document.write(aux);



















