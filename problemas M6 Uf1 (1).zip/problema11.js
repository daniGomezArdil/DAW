var fila=prompt("Dime el numero de filas");
var columna=prompt("Dime el numero de columnas");
var i,j;
var clase;
document.write("<table border=1>");
for (i=1;i<=fila;i++){
	document.write("<tr>");
	for (j=1;j<=columna;j++){
		/* OPCION 1 
		if (i%2==0){
			if (j%2==0){
				clase="azul";
			}
			else {
				clase="rojo";
			}
		}
		else {
			if (j%2==0){
				clase="rojo";
			}
			else {
				clase="azul";
			}
		}
		*/
		/* opcion 2
		clase = (i%2==0)? ((j%2==0)?"azul":"rojo"):((j%2==0)?"rojo":"azul"); 
		*/
		/*opcion 3 */
		clase = ((i+j)%2==0)? "azul":"rojo"; 
		
		
		
		document.write("<td class="+clase+">"+i+"."+j+"</td>");
	}
	document.write("</tr>");
}
document.write("</table>");







