var total=20;
var fibonacci;
var anterior=1;
var anteriorAnterior=1;

document.write("Valor 1: 1<br />");
document.write("Valor 2: 1<br />");
var x;
for (x=3;x<=total;x++){
	fibonacci=anterior + anteriorAnterior;
	anteriorAnterior=anterior;
	anterior=fibonacci;
	document.write("Valor "+x+": " + fibonacci +"<br />");
}
