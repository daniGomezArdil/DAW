function prueba(){
	window.moveBy(10,10);
}



















