var hora = prompt("Dime la hora")*1;
var minuto = prompt("Dime los minutos")*1;
var segundo = prompt("Dime los segundos")*1;

segundo +=1;
/*if (segundo>=60){
	segundo="00";
	minuto+=1;
}
if (minuto>=60){
	minuto=0;
	hora+=1;
}
if (hora>=24){
	hora=0;
}
*/

/*  SEGUNDA APROXIMACION   */
/*
segundo= (segundo>=60)?"00":segundo;
minuto=(segundo=="00")?minuto+1:minuto;
minuto=(minuto>=60)?"00":minuto;
hora=(minuto=="00")?hora+1:hora;
hora=(hora>=24)?"00":hora;
*/

segundo= (segundo>=60)?"00":segundo;
minuto=(segundo=="00")?((minuto+1>=60)?"00":minuto+1):minuto;
hora=(minuto=="00")?hora+1:hora;
hora=(hora>=24)?"00":hora;
document.write("<h1>"+hora + ":"+minuto+":"+segundo+"</h1>");







