//FILE: MAIN.JS
//1. DECLARACION DE VARIABLES GLOBALES
var frase="";
var i;
var cuantas=0;
var cuantos=0;
//2. CODIGO A EJECUTAR
frase=prompt("Dime una frase");
for (i=0;i<frase.length;i++){
	if (esVocal(frase.charAt(i))==true){
		cuantas=cuantas+1;
	}
	if (esEspacio(frase.charAt(i))==true){
		cuantos=cuantos+1;
	}

}
document.write(cuantas);