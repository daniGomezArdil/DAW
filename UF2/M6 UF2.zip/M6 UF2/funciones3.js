// FILE: FUNCIONES.JS

function prueba(){
	alert("hola");
}

var esVocal=function (letra){
	aux=letra.toLowerCase();
	if ((aux=='a') || (aux=='e') || (aux=='i') ||(aux=='o') ||(aux=='u')){
		return true;
	}
	return false;
}

var esEspacio=function (letra){
	if (letra==' '){
		return true;
	}
	return false;
}



